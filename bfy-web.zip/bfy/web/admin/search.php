<?php
$mod='blank';
include("../api.inc.php");
$title='搜索商品';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>您可以从此处搜索内容。</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					
					
					
					
            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">输入信息搜索</h3>
                      
                      
                    </div>
                    <div class="panel-body">

                      <form action="./kmlist.php" method="get" role="form" class="form-inline validate">  
                        <div class="form-group">

                        <div class="form-group">

                          <select class="form-control" name="type">
                            <option value="1">卡密</option>
                            <option value="2">账号</option>
                          </select>
                            
                        </div>

                        <div class="form-group">
                          <input type="text" class="form-control" size="25" placeholder="内容" name="kw"  data-validate="required"/>
                        </div>

                        <div class="form-group">
                          <button type="submit" class="btn btn-info btn-single">查询</button>
                        </div>
                        
                        </div>
                        
                      </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
					
					
					
					
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>