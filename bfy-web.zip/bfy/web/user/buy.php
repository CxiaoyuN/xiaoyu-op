<?php
$mod='blank';
include("../api.inc.php");

$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
if(!$res){
//	header('location: login.php');
		exit("<script language='javascript'>alert('未正确登录，或用户名或密码不正确！');window.location.href='/user/login.php';</script>");
}

/*获取代理信息*/
$daili_info = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
$daili_info_id=$daili_info['dlid'];
if($daili_info_id){
	
}else{
	$daili_info_id=0;
}

//判断设置
$rs=$DB->get_row("SELECT * FROM auth_config");
$kmtype_con=$rs['kmtype'];
if($kmtype_con==1){
  $daili_info_id=0;
};
//echo "<script language='javascript'>alert('获取代理信息：".$daili_info_id."');</script>";

if($daili_info_id){
	$config_dl = $DB->get_row("SELECT * FROM auth_daili WHERE id='$daili_info_id' limit 1");
	$config_name=$config_dl['name'];//代理姓名
	$config_qq=$config_dl['qq'];
	$config_tel=$config_dl['tel'];
	$config_buy=$config_dl['buy'];//购买链接
	$config_buy2=$config_dl['buy2'];//购买代码
	//echo "<script language='javascript'>alert('获取代理信息：".$config_name."');</script>";
}else{
	$rs=$DB->get_row("SELECT * FROM website");
	$config_name=$rs['title'];
	$config_qq=$rs['qq'];
	$config_tel=$rs['tel'];

	$rs2=$DB->get_row("SELECT * FROM auth_config");
	$config_buy=$rs2['shopUrl'];
	$config_buy2=$rs2['shopCode'];
}


?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                         <br> <h1 class="widget-heading h3 text-black"><strong><?php echo "您好，".$res['iuser'];?>！<?=($res['i']?'</strong><div class="btn btn-success m-t-10">账号正常</div>':'<div class="btn btn-danger m-t-10">账号禁用</div>')?></h1>
                                             <br>
                                      </div> 
                                  </div>
                            </div>
							<div class="widget-content widget-content-mini themed-background-muted">
					
			
					
					
					<div class="row">
					
		                    <div id="addtype_list" class="row">
		                                        <?php

		                                        $rs=$DB->query("SELECT * FROM `kmtype` WHERE `dlid` = '$daili_info_id' and i='0'");
		                                        //$rs=$DB->query("SELECT * FROM `kmtype`");//读取全部套餐

		                                        while($res = $DB->fetch($rs))
		                                        { ?>
		                                        <div class="col-sm-4 text-center">
												<a href="javascript:void(0)" class="widget themed-background-social">
												<div class="widget-content themed-background-social clearfix">
		                                            <div class="xe-header themed-background-social">
		                                              <div class="xe-icon">
		                                                
		                                              </div>
		                                              <div class="xe-label">
		                                                <h3><strong><?=$res['name']?></strong></h3>
		                                              </div>
		                                            </div>
		                                            <div class="xe-body themed-background-social">
		                                              
		                                              <ul class="list-unstyled">
		                                                <li>
		                                                  <label>
		                                                    <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-state"><span></span></div></div>
		                                                    <h3><span><?=$res['days']?>天使用时间</span></h3>
		                                                  </label>
		                                                </li>
		                                                <li>
		                                                  <label>
		                                                    <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-state"><span></span></div></div>
		                                                    <h3><span><?=round(($res['maxll'])/1024/1024)?>GB流量</span></h3>
		                                                  </label>
		                                                </li>
		                                                <li>
		                                                  <label>
		                                                    <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-state"><span></span></div></div>
		                                                    <h3><span><?=$res['km_rmb']?>元</span></h3>
		                                                  </label>
		                                                </li>
		                                              </ul>
		                                              
		                                            </div>
						<?php
							/*获取支付宝*/
							$alpay= $DB->get_row("SELECT * FROM alipay");
							$alpay_on=$alpay['partner'];
							if($alpay_on<>""){
								$bay_btn="<a href=pay.php?id=".$res['id']."&user=".$u."&pass=".$p." type='submit' class=' themed-background-muted btn btn-white text-black btn-single btn-block'>立即购买</a>";
							}
							else{
								if($config_buy<>""){
									$bay_btn="<a href=".$config_buy." target='_blank' type='submit' class=' themed-background-muted btn btn-white text-black btn-single btn-block'>立即购买</a>";
								}
							}
						?>
						<a href="javascript:void(0)" class="widget">
												
		                                            <div class="xe-footer themed-background-social">
		                                                     <?php echo $bay_btn; ?>
		                                            </div></a>
		                                          </div>
		                                        </a>
												</div>

		                                        <?php }
						/*if($rs){

						}else{
							echo '<div class="col-sm-12"><div class="alert alert-white">
						                                        <button type="button" class="close">
						                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
											<span class="sr-only">Close</span>
										</button>
										暂无套餐可购买！
									</div></div>';
						}*/
		                                        ?>


		                    </div>

			</div>

					
					
					
					
					
					
					
					
					      </div>
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>