<?php
$dl=$DB->get_row("SELECT * FROM website where daili = $web_dl");
?>
                    <div id="sidebar">
                    <!-- Sidebar Brand -->
                    <div id="sidebar-brand" class="themed-background">
                        <a href="index.php?id=<?php echo $res['id']?>&user=<?php echo $u?>&pass=<?php echo $p?>" class="sidebar-title">
                            <i class="fa fa-cube"></i> <span class="sidebar-nav-mini-hide"><strong><?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?></strong></span>
                        </a>

                    </div>
                    <!-- END Sidebar Brand -->

                    <!-- Wrapper for scrolling functionality -->
                    <div id="sidebar-scroll">
                        <!-- Sidebar Content -->
                        <div class="sidebar-content">
                            <!-- Sidebar Navigation -->
                            <ul class="sidebar-nav">
                                <li>
                                    <a href="index.php?id=<?php echo $res['id']?>&user=<?php echo $u?>&pass=<?php echo $p?>" class=" active"><i class="gi gi-compass sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">用户首页</span></a>
                                </li>
                                <li class="sidebar-separator">
                                    <i class="fa fa-ellipsis-h"></i>
                                </li>
								 <li>
                                    <a href="buy.php?user=<?php echo $u?>&pass=<?php echo $p?>"><i class="gi gi-shop_window sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">流量商店</span></a>
                                </li>
								
								
								<li>
                                    <a href="ios.php?user=<?php echo $u?>&pass=<?php echo $p?>"><i class="si si-apple sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">苹果线路</span></a>
                                </li>
								<li>
                                    <a href="/web/ios.php?user=<?php echo $u?>&pass=<?php echo $p?>"><i class="si si-apple sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">苹果安装</span></a>
                                </li>
                                
						
								<li>
                                    <a target="_blank" href="/web/and.php?name=<?php echo $dl['name'] ?>"><i class="si si-android sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">安卓安装</span></a>
                                </li>
								
								
								<li>
                                    <a target="_blank" href="/web/index.php?name=<?php echo $dl['name'] ?>#client-reviews"><i class="gi gi-circle_exclamation_mark sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">常见问题</span></a>
                                </li>
								
								
								<li>
								<a href="#" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="gi gi-more_items sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">商家信息</span></a>
                                    <ul>
                                        <li>
                                            <a class="gi gi-user" href="#">&nbsp;<?php echo $config_name ?></a>
                                        </li>
                                    
									 
                                        <li>
                                            <a class="si si-quora" href="#">&nbsp;<?php echo $config_qq ?></a>
                                        </li>
										
										
										<li>
                                            <a  class="gi gi-earphone" href="#">&nbsp;<?php echo $config_tel ?></a>
                                        </li>
                                    </ul>
                                </li>
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
                                
                            </ul>
                            <!-- END Sidebar Navigation -->

                            <!-- Color Themes -->
                            <!-- Preview a theme on a page functionality can be found in ../asset/js/app.js - colorThemePreview() -->
                            <div class="sidebar-section sidebar-nav-mini-hide">
                                
                                
                            </div>
                            <!-- END Color Themes -->
                        </div>
                        <!-- END Sidebar Content -->
                    </div>
                    <!-- END Wrapper for scrolling functionality -->

                    <!-- Sidebar Extra Info -->
                    <div id="sidebar-extra-info" class="sidebar-content sidebar-nav-mini-hide">
                        <div class="push-bit">
                            <span class="pull-right">
                                <a href="javascript:void(0)" class="text-muted"><i class="fa fa-plus"></i></a>
                            </span>
                            
                        </div>
                        
                        <div class="text-center">
                            
                            <small><span>2017</span> &copy; <a href="../web/" target="_blank"><?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?></a></small>
                        </div>
                    </div>
                    <!-- END Sidebar Extra Info -->
                </div>