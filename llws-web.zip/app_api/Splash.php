<?php
	$data["status"] = "error";
	$data["url"] = "http://abc.cn/test.jpg"; //请在此填写下载地址