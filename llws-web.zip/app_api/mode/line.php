<?php
	$line_grop = db('line_grop')->where(array('show'=>'1'))->order('id ASC')->select();
	?>
<link rel="stylesheet" type="text/css" href="./css/style.css?r" />
<ul id="pagenavi" class="page">
		<?php
		$i = 1;
		foreach($line_grop as $vo){
			$p = $i == 1 ? 'active' :'';
			$i++;
			?>
		<li class="gitem"><a href="#" class="<?php echo $p?>"><?php echo $vo['name']?></a></li>
		<?php }?>
     
 </ul>
    <div id="slider" class="swipe">
      <ul class="box01_list">
       <?php 
	   $show = true;
	   foreach($line_grop as $vo){
		$ss = $show ? '' :'display:none';
		   ?>
				<li class="li_list" style="<?php echo $ss?>">
				<!---->
					<div class="main">
					<ul class="list-group">
					<?php  $show = false;
						$line = db('line')->where(array('show'=>'1','group'=>$vo['id']))->order('id DESC')->select();
						if($line){
							foreach($line as $vos){?>
							<li class="list-group-item"><b><?php echo $vos['name']?></b>&nbsp;<span class="badge"><?php echo $vos['type']?></span><br><p><?php echo $vos['label']?></p><button type="button" class="btn btn-primary btn-sm" onclick="addLine('<?php echo $vos['id']?>')">安装</button></li>
						<?php }
						}else{
						?>
						<div class="alert alert-info">很遗憾匹配不到相关线路哦！再等一等吧~~~</div>
						<?php
						}
						?>
					</ul>
					<div style="clear:both"></div>
					</div>
					</li>
				<?php }?>
				
			
		<!---->
      </ul>
</div>

<script type="text/javascript">
$(function(){
	$(".gitem").click(function(){
		var n = $(".gitem").index(this);
		$(".gitem a").removeClass("active").eq(n).addClass("active");
		$(".li_list").hide().eq(n).show();
	});
});
</script>

<script>
	var name_tmp = "";
	function addLine(id){
		$.post(
			'getLine.php',
			{
				'id':id,
				'key':'<?php echo $_GET["app_key"] ?>',
				'username':'<?php echo $_GET["username"] ?>',
				'password':'<?php echo $_GET["password"] ?>'
			},function(data){
				if(data.status == 'success'){
					//window.myObj.writeFile('test.ovpn','<?php echo base64_encode(file_get_contents('1.ovpn'))?>','download');
					name_tmp = data.name;
					window.myObj.writeFile(data.name+'.ovpn',data.content,'download'); 
				}else{
					alert(data.msg);
				}
			},"JSON");
		  
	}
	function cli_sendData(status,type,msg){
		if(type == 'file_w'){
			if(status == 'success'){
				window.myObj.installPro('download/'+name_tmp+'.ovpn');
			}else{
				$('.tip').html("写入文件失败");
			}
		}
	}
	</script>	