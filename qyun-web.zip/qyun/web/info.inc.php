<?php
//购买说明
$info_buy = '激活码购买地址：<a target="_blank" href="http://www.qyunl.com/">http://www.qyunl.com/</a>';

//联系QQ
$info_qq = '100340768';

//第二次续费另外赠送天数
$twice_free = 0; 