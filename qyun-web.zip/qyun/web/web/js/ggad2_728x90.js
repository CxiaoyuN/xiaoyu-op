document.writeln("<link type=\"text/css\" rel=\"stylesheet\" href=\"http://www.cssmoban.com/statics/css/astyle.css\" />");
document.writeln("<div align=\"center\">");
document.writeln("<script async src=\"//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js\"></script>");
document.writeln("<!-- cssmoban_728*90_show -->");
document.writeln("<ins class=\"adsbygoogle\"");
document.writeln("     style=\"display:inline-block;width:728px;height:90px\"");
document.writeln("     data-ad-client=\"ca-pub-1542822386688301\"");
document.writeln("     data-ad-slot=\"3852412413\"></ins>");
document.writeln("<script>");
document.writeln("(adsbygoogle = window.adsbygoogle || []).push({});");
document.writeln("</script>");
document.writeln("</div>");
document.writeln("<script>QIHOO_UNION_F_SLOT={w:120, h:300, ls:\"s5cf5928485\",position:3, display:0,origin:2};</script><script src=\"http://s.lianmeng.360.cn/so/f.js\" charset=\"utf-8\"></script>");


