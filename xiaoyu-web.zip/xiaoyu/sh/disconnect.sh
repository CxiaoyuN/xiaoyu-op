#!/bin/sh
#集群和云数据库请不要改此文件直接修改同目录里的peizhi.cfg文件
source /etc/openvpn/peizhi.cfg
user=$common_name
#防SQL注入
if [[ $user =~ "ov" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/wwwroot/login-sql.log
	user=$NOW
elif [[ $user =~ "@’" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/wwwroot/login-sql.log
	user=$NOW
elif [[ $user =~ "set" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/wwwroot/login-sql.log
	user=$NOW
elif [[ $user =~ "%’" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/wwwroot/login-sql.log
	user=$NOW
elif [[ $user =~ "lm’" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/wwwroot/login-sql.log
	user=$NOW
elif [[ $user =~ "drop" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/wwwroot/login-sql.log
	user=$NOW
elif [[ $user =~ "database" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/wwwroot/login-sql.log
	user=$NOW
elif [[ $user =~ ";" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/wwwroot/login-sql.log
	user=$NOW
elif [[ $user =~ " " ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/wwwroot/login-sql.log
	user=$NOW
elif [[ $user =~ "delect" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/wwwroot/login-sql.log
	user=$NOW
elif [[ $user =~ "select" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/wwwroot/login-sql.log
	user=$NOW
elif [[ $user =~ "update" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/wwwroot/login-sql.log
	user=$NOW
elif [[ $user =~ ".php" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/wwwroot/login-sql.log
	user=$NOW
elif [[ $user =~ ".asp" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/wwwroot/login-sql.log
	user=$NOW
fi
#dingd.cn & qyunl.com
if [[ $appopen == "yes" ]];then
curl "http://$apphost/app_api/$appkey.php?name=$user&s=$bytes_sent&r=$bytes_received&version=2"
else
mysql -h$localhost -u$root -p$mima -e "use ov;SELECT isent FROM openvpn WHERE iuser='$user';">>addlogs.txt
sleep 1
mysql -h$localhost -u$root -p$mima -e "use ov;SELECT irecv FROM openvpn WHERE iuser='$user';">>addlogr.txt
sent=$(sed -n 2p addlogs.txt)
recv=$(sed -n 4p addlogr.txt)
rm -rf addlogs.txt
sent=$[$sent+$bytes_sent]
recv=$[$recv+$bytes_received]
mysql -h$localhost -u$root -p$mima -e "use ov;UPDATE openvpn SET isent = '$sent' WHERE iuser='$user';"
sleep 1
mysql -h$localhost -u$root -p$mima -e "use ov;UPDATE openvpn SET irecv = '$recv' WHERE iuser='$user';"
fi
#小羽