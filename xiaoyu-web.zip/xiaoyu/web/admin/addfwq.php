<?php
$mod='blank';
include("../api.inc.php");
$title='添加服务器';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>您可以在此添加已集群的服务器，方便统一管理。</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					<!--end--><!--end--><!--end--><!--end--><!--end--><!--end--><!--end--><!--end-->
					
					        <div class="col-sm-12">
                                        <a href="javascript:void(0)" class="widget">
                                            <div class="widget-content themed-background text-light-op">
                                                <i class="fa fa-fw fa-chevron-right"></i> <strong><font><font>请输入服务器信息</font></font></strong>
                                            </div>
                                           <div class="panel-body">

                      <?php
                      if($_POST['name']){
                      echo '<div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>';
                      $name = daddslashes($_POST['name']);
                      $ipport = daddslashes($_POST['ipport']);

                      if(!$DB->get_row("select * from `auth_fwq` where `name`='$name' limit 1")){
                        $sql="insert into `auth_fwq` (`name`,`ipport`) values ('{$name}','{$ipport}')";
                        if($DB->query($sql))
                          echo "成功添加一个服务器";
                        else
                          echo "添加失败：".$DB->error();
                      }else{
                        echo "<script>alert('该服务器已存在！');history.go(-1);</script>";
                      }
                      echo '</div>';
                      //exit;
                      }
                      ?>


              <form action="./addfwq.php" method="post" role="form" class="form-horizontal validate">
                
                <div class="form-group">
                  <div class="col-sm-12">
                    <input type="text" class="form-control" id="field-1" placeholder="服务器备注   如：高防1号" name="name" data-validate="required">
                  </div>
                </div>

                <div class="form-group">
                  <div class="col-sm-12">
                    <input type="text" class="form-control" id="field-1" placeholder="ip地址:端口  如：10.10.10.10:1234" name="ipport" data-validate="required">
                  </div>
                </div>

                <button type="submit" type="button" class="btn btn-info">添加</button>
                
              </form>
                      
                    </div>
                                            
                                        </a>
                                    </div>
					
					
					
					
					
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>