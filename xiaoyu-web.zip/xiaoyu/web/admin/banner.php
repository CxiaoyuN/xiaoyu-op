<?php
$mod='blank';
include("../api.inc.php");
$title='图片管理';
$bn=$DB->get_row("SELECT * FROM banner");
$img1=$bn['img1'];
$tit1=$bn['tit1'];
$info1=$bn['info1'];
$img2=$bn['img2'];
$tit2=$bn['tit2'];
$info2=$bn['info2'];
$img3=$bn['img3'];
$tit3=$bn['tit3'];
$info3=$bn['info3'];
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>您可以在此更新引导页的幻灯片。</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					
					
					
					
					
					
					<div class="row">
                <div class="col-sm-12">
                <div class="alert alert-info">
                    <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>
                    <strong>重要：</strong> 默认幻灯片ID必须是0，请勿修改删除！
                  </div>
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">请输入内容进行更新</h3>
                      
                     
                    </div>
                    <div class="panel-body">

<?php

$my=$_POST['my'];
if($my=='config'){
echo '<div class="alert';
$img1_c=$_POST['img1'];
$tit1_c=$_POST['tit1'];
$info1_c=$_POST['info1'];
$img2_c=$_POST['img2'];
$tit2_c=$_POST['tit2'];
$info2_c=$_POST['info2'];
$img3_c=$_POST['img3'];
$tit3_c=$_POST['tit3'];
$info3_c=$_POST['info3'];
$sql=$DB->query("UPDATE `banner` SET `img1` = '$img1_c',`tit1` = '$tit1_c',`info1` = '$info1_c',`img2` = '$img2_c',`tit2` = '$tit2_c',`info2` = '$info2_c',`img3` = '$img3_c',`tit3` = '$tit3_c',`info3` = '$info3_c' WHERE `banner`.`id` = 0");
  
if($sql){echo ' alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>保存成功！';}
else{echo ' alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>保存失败！';}
echo '</div>';
//echo $img1_c;
//exit;
echo "<style>#banner{display: none;}</style>";
}

 ?>

              <form id="banner" action="./banner.php" method="post" role="form" class="form-horizontal validate">
                
                <div class="form-group">
                  <input type="hidden" name="my" value="config"/>
                  <label class="col-sm-2 control-label">大图设置1</label>
                  <div class="col-sm-10">
                    <div class="input-group">
                      <span class="input-group-addon">1920px*1282px</span>
                      <input type="text" class="form-control" value="<?php echo $img1;?>" name="img1" data-validate="required,url">
                      <span class="input-group-addon"><a target="_blank" href="<?php echo $img1;?>"><i class="linecons-search"></i></a></span>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <div class="input-group">
                        <span class="input-group-addon">标题</span>
                        <input type="text" class="form-control" id="field-1" value="<?php echo $tit1;?>" name="tit1" data-validate="required">
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <div class="input-group">
                        <span class="input-group-addon">描述</span>
                        <input type="text" class="form-control" id="field-1" value="<?php echo $info1;?>" name="info1" data-validate="required">
                    </div>
                  </div>
                </div>

                <div class="form-group-separator"></div>

                <div class="form-group">
                  <input type="hidden" name="my" value="config"/>
                  <label class="col-sm-2 control-label">大图设置2</label>
                  <div class="col-sm-10">
                    <div class="input-group">
                      <span class="input-group-addon">1920px*1282px</span>
                      <input type="text" class="form-control" value="<?php echo $img2;?>" name="img2" data-validate="required,url">
                      <span class="input-group-addon"><a target="_blank" href="<?php echo $img2;?>"><i class="linecons-search"></i></a></span>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <div class="input-group">
                        <span class="input-group-addon">标题</span>
                        <input type="text" class="form-control" id="field-1" value="<?php echo $tit2;?>" name="tit2" data-validate="required">
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <div class="input-group">
                        <span class="input-group-addon">描述</span>
                        <input type="text" class="form-control" id="field-1" value="<?php echo $info2;?>" name="info2" data-validate="required">
                    </div>
                  </div>
                </div>

                <div class="form-group-separator"></div>

                <div class="form-group">
                  <input type="hidden" name="my" value="config"/>
                  <label class="col-sm-2 control-label">大图设置3</label>
                  <div class="col-sm-10">
                    <div class="input-group">
                      <span class="input-group-addon">1920px*1282px</span>
                      <input type="text" class="form-control" value="<?php echo $img3;?>" name="img3" data-validate="required,url">
                      <span class="input-group-addon"><a target="_blank" href="<?php echo $img3;?>"><i class="linecons-search"></i></a></span>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <div class="input-group">
                        <span class="input-group-addon">标题</span>
                        <input type="text" class="form-control" id="field-1" value="<?php echo $tit3;?>" name="tit3" data-validate="required">
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <div class="input-group">
                        <span class="input-group-addon">描述</span>
                        <input type="text" class="form-control" id="field-1" value="<?php echo $info3;?>" name="info3" data-validate="required">
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-6">
                    <button type="submit" type="button" class="btn btn-info">保存</button>
                  </div>
                </div>
                
              </form> 
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
					
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>