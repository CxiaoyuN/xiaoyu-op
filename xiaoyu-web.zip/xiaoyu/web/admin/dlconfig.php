<?php
/**
 * 代理管理
**/
$mod='blank';
include("../api.inc.php");
$title='代理页面管理';
$rs=$DB->get_row("SELECT * FROM auth_config");
$regok=$rs['regok'];
$member_reg=$rs['member_reg'];
$activeok=$rs['activeok'];
$dl0=$rs['dl0'];
$dl1=$rs['dl1'];
$dl2=$rs['dl2'];
$dl3=$rs['dl3'];
$dl4=$rs['dl4'];
$dl5=$rs['dl5'];
$dls0=$rs['dls0'];
$dls1=$rs['dls1'];
$dls2=$rs['dls2'];
$dls3=$rs['dls3'];
$dls4=$rs['dls4'];
$dls5=$rs['dls5'];
$gongg=$rs['gg'];
$gonggs=$rs['ggs'];
$shopUrl_con=$rs['shopUrl'];
$shopCode_con=$rs['shopCode'];
$daili_cash_con=$rs['daili_cash'];
$reg_cash_con=round($rs['reg_cash']/1024/1024);
$user_cash_con=round($rs['user_cash']/1024/1024);
$qian_con=round($rs['qian']/1024/1024);
$user_endtime_con =$rs['user_endtime'];
$wx0=$rs['wx0'];
$wx1=$rs['wx1'];
$wx2=$rs['wx2'];
$wx3=$rs['wx3'];
$wx4=$rs['wx4'];
$wx5=$rs['wx5'];
$kmtype_con=$rs['kmtype'];
$down_con=$rs['down'];

if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>您在这里可以管理代理页面的公告和代理拿货价格</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					
					
					
					
					
					
					<div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">请输入管理信息</h3>
                      
                      
                    </div>
                    <div class="panel-body">

<?php

$my=$_POST['my'];
if($my=='config'){
echo '<div class="alert';
$ak=$_POST['ak'];
$rk=$_POST['rk'];
$member_reg=$_POST['member_reg'];
$dl00=$_POST['dl0'];
$dl01=$_POST['dl1'];
$dl02=$_POST['dl2'];
$dl03=$_POST['dl3'];
$dl04=$_POST['dl4'];
$dl05=$_POST['dl5'];
$dls00=$_POST['dls0'];
$dls01=$_POST['dls1'];
$dls02=$_POST['dls2'];
$dls03=$_POST['dls3'];
$dls04=$_POST['dls4'];
$dls05=$_POST['dls5'];
$gg=daddslashes($_POST['gongg']);
$ggs=daddslashes($_POST['gonggs']);
$shopUrl=daddslashes($_POST['shopUrl']);
$shopCode=daddslashes($_POST['shopCode']);
$daili_cash=daddslashes($_POST['daili_cash']);
$reg_cash=daddslashes($_POST['reg_cash'])*1024*1024;
$user_cash=daddslashes($_POST['user_cash'])*1024*1024;
$qian=daddslashes($_POST['qian'])*1024*1024;
$user_endtime=daddslashes($_POST['user_endtime']);
$wx00=$_POST['wx0'];
$wx01=$_POST['wx1'];
$wx02=$_POST['wx2'];
$wx03=$_POST['wx3'];
$wx04=$_POST['wx4'];
$wx05=$_POST['wx5'];
$kmtype=$_POST['kmtype'];
$down=$_POST['down'];
$sql=$DB->query("update `auth_config` set  `gg`='$gg',`ggs`='$ggs',`activeok`='$ak',`regok`='$rk',`member_reg`='$member_reg',`dl1`='$dl01',`dl2`='$dl02',`dl3`='$dl03',`dl4`='$dl04',`dl5`='$dl05',`dl0`='$dl00',`dls1`='$dls01',`dls2`='$dls02',`dls3`='$dls03',`dls4`='$dls04',`dls5`='$dls05',`dls0`='$dls00',`shopUrl`='$shopUrl',`daili_cash`='$daili_cash',`reg_cash`='$reg_cash',`user_cash`='$user_cash',`qian`='$qian',`user_endtime`='$user_endtime',`shopCode`='$shopCode',`wx0`='$wx00',`wx1`='$wx01',`wx2`='$wx02',`wx3`='$wx03',`wx4`='$wx04',`wx5`='$wx05',`kmtype`='$kmtype',`down`='$down' where 1");
  
if($sql){echo ' alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>保存成功！';}
else{echo ' alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>保存失败！';}
echo '</div>';
echo "<style>#dlconfig{display: none;}</style>";
//exit;
}

 ?>

              <form id="dlconfig" action="./dlconfig.php" method="post" role="form" class="form-horizontal validate">
                
                <div class="form-group">
                  <input type="hidden" name="my" value="config"/>
                  <label class="col-sm-2 control-label">代理公告</label>
                  <div class="col-sm-9">
                    <textarea class="form-control" cols="5" id="field-5" placeholder="请输入代理公告" name="gongg"><?php echo $gongg;?></textarea>
                  </div>
                </div>

                <div class="form-group">
                  <input type="hidden" name="my" value="config"/>
                  <label class="col-sm-2 control-label">用户公告</label>
                  <div class="col-sm-9">
                    <textarea class="form-control" cols="5" id="field-5" placeholder="请输入公告公告" name="gonggs"><?php echo $gonggs;?></textarea>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">购买链接</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="field-1" value="<?php echo $shopUrl_con;?>" name="shopUrl" data-validate="url">
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">支付代码</label>
                  <div class="col-sm-9">
                    <textarea class="form-control" cols="5" id="field-5" name="shopCode"><?php echo $shopCode_con;?></textarea><br>
                    <p class="text-success">* 此处为第三方平台实现支付，<a target="_blank" class="text-success" href="http://www.jiasale.com/">打开此链接</a>注册后插入代码</p>
                  </div>
                </div>

                <div class="form-group-separator"></div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">代理推荐返现</label>
                  <div class="col-sm-9">
                    <div class="input-group">
                      <input type="text" class="form-control" id="field-1" value="<?php echo $daili_cash_con;?>" name="daili_cash" data-validate="required,number">
                      <span class="input-group-addon">元</span>  
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">新注册用户赠送流量</label>
                  <div class="col-sm-2">
                    <div class="input-group">
                      <input type="text" class="form-control" id="field-1" value="<?php echo $reg_cash_con;?>" name="reg_cash" data-validate="required,number">
                      <span class="input-group-addon">MB</span>  
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="input-group">
                      <input type="text" class="form-control" id="field-1" value="<?php echo $user_endtime_con;?>" name="user_endtime" data-validate="required,number">
                      <span class="input-group-addon">天</span>  
                    </div>
                  </div>
                  <div class="col-sm-5">
                    <p class="text-info">* 赠送如果设置为0，注册的用户默认就禁用</p>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">推荐用户赠送流量</label>
                  <div class="col-sm-4">
                    <div class="input-group">
                      <input type="text" class="form-control" id="field-1" value="<?php echo $user_cash_con;?>" name="user_cash" data-validate="required,number">
                      <span class="input-group-addon">MB</span>  
                    </div>
                  </div>
                  <div class="col-sm-5">
                    <p class="text-info">* 推荐后的用户，采用卡密激活即可获取赠送流量</p>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">签到赠送流量</label>
                  <div class="col-sm-9">
                    <div class="input-group">
                      <input type="text" class="form-control" id="field-1" value="<?php echo $qian_con;?>" name="qian" data-validate="required,number">
                      <span class="input-group-addon">MB</span>  
                    </div>
                  </div>
                </div>

                <div class="form-group-separator"></div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">代理自主设计套餐</label>
                  <div class="col-sm-9">
                <?php 
                if($kmtype_con==1){
                  echo '
                      <label class="radio-inline">
                        <input type="radio" name="kmtype" value="0">
                        开放
                      </label>
                      <label class="radio-inline">
                        <input type="radio" name="kmtype" checked value="1">
                        关闭
                      </label>
                  ';
                }else{
                  echo '
                      <label class="radio-inline">
                        <input type="radio" name="kmtype" checked value="0">
                        开放
                      </label>
                      <label class="radio-inline">
                        <input type="radio" name="kmtype" value="1">
                        关闭
                      </label>
                  ';}
                ?>
                  </div>
                </div>  

                <div class="form-group">
                  <label class="col-sm-2 control-label">会员中心下载线路</label>
                  <div class="col-sm-9">
                <?php 
                if($down_con==1){
                  echo '
                      <label class="radio-inline">
                        <input type="radio" name="down" value="0">
                        开放
                      </label>
                      <label class="radio-inline">
                        <input type="radio" name="down" checked value="1">
                        关闭
                      </label>
                  ';
                }else{
                  echo '
                      <label class="radio-inline">
                        <input type="radio" name="down" checked value="0">
                        开放
                      </label>
                      <label class="radio-inline">
                        <input type="radio" name="down" value="1">
                        关闭
                      </label>
                  ';}
                ?>
                  </div>
                </div>  

                <div class="form-group-separator"></div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">代理注册</label>
                  <div class="col-sm-9">
                <?php 
                if($regok==1){
                  echo '
                      <label class="radio-inline">
                        <input type="radio" name="rk" value="0">
                        开放
                      </label>
                      <label class="radio-inline">
                        <input type="radio" name="rk" checked value="1">
                        关闭
                      </label>
                  ';
                }else{
                  echo '
                      <label class="radio-inline">
                        <input type="radio" name="rk" checked value="0">
                        开放
                      </label>
                      <label class="radio-inline">
                        <input type="radio" name="rk" value="1">
                        关闭
                      </label>
                  ';}
                ?>
                  </div>
                </div>  

                <div class="form-group">
                  <label class="col-sm-2 control-label">用户注册</label>
                  <div class="col-sm-9">
                <?php 
                if($member_reg==1){
                  echo '
                      <label class="radio-inline">
                        <input type="radio" name="member_reg" value="0">
                        开放
                      </label>
                      <label class="radio-inline">
                        <input type="radio" name="member_reg" checked value="1">
                        关闭
                      </label>
                  ';
                }else{
                  echo '
                      <label class="radio-inline">
                        <input type="radio" name="member_reg" checked value="0">
                        开放
                      </label>
                      <label class="radio-inline">
                        <input type="radio" name="member_reg" value="1">
                        关闭
                      </label>
                  ';}
                ?>
                  </div>
                </div>  

                <div class="form-group hide">
                  <label class="col-sm-2 control-label">注册默认开通</label>
                  <div class="col-sm-9">
                  <select name="ak" class="form-control">
                  <?php 
          if($activeok==1){
            echo ' <option value="0">默认开通账号</option><option value="1" selected="selected">默认关闭账号</option>';
          }else{ echo ' <option value="0" selected="selected" >默认开通账号</option><option value="1" >默认关闭账号</option>';}
                  ?>
              </select>
                  </div>
                </div>  

                <div class="form-group-separator"></div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">普通代理价格</label>
                  <div class="col-sm-9">
                    <div class="row">
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $dl0;?>" name="dl0" data-validate="required,number">
                          <span class="input-group-addon">元/天</span>  
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $dls0;?>" name="dls0" data-validate="required,number">
                          <span class="input-group-addon">元/GB</span> 
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $wx0;?>" name="wx0" data-validate="required,number">
                          <span class="input-group-addon">元/无限流量账号</span> 
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">铜牌代理价格</label>
                  <div class="col-sm-9">
                    <div class="row">
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $dl1;?>" name="dl1" data-validate="required,number">
                          <span class="input-group-addon">元/天</span>  
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $dls1;?>" name="dls1" data-validate="required,number">
                          <span class="input-group-addon">元/GB</span> 
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $wx1;?>" name="wx1" data-validate="required,number">
                          <span class="input-group-addon">元/无限流量账号</span> 
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="form-group has-info">
                  <label class="col-sm-2 control-label">银牌代理价格</label>
                  <div class="col-sm-9">
                    <div class="row">
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $dl2;?>" name="dl2" data-validate="required,number">
                          <span class="input-group-addon">元/天</span>  
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $dls2;?>" name="dls2" data-validate="required,number">
                          <span class="input-group-addon">元/GB</span> 
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $wx2;?>" name="wx2" data-validate="required,number">
                          <span class="input-group-addon">元/无限流量账号</span> 
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="form-group has-success">
                  <label class="col-sm-2 control-label">金牌代理价格</label>
                  <div class="col-sm-9">
                    <div class="row">
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $dl3;?>" name="dl3" data-validate="required,number">
                          <span class="input-group-addon">元/天</span>  
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $dls3;?>" name="dls3" data-validate="required,number">
                          <span class="input-group-addon">元/GB</span> 
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $wx3;?>" name="wx3" data-validate="required,number">
                          <span class="input-group-addon">元/无限流量账号</span> 
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="form-group has-warning">
                  <label class="col-sm-2 control-label">钻石代理价格</label>
                  <div class="col-sm-9">
                    <div class="row">
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $dl4;?>" name="dl4" data-validate="required,number">
                          <span class="input-group-addon">元/天</span>  
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $dls4;?>" name="dls4" data-validate="required,number">
                          <span class="input-group-addon">元/GB</span> 
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $wx4;?>" name="wx4" data-validate="required,number">
                          <span class="input-group-addon">元/无限流量账号</span> 
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="form-group has-error">
                  <label class="col-sm-2 control-label">至尊代理价格</label>
                  <div class="col-sm-9">
                    <div class="row">
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="时间" value="<?php echo $dl5;?>" name="dl5" data-validate="required,number">
                          <span class="input-group-addon">元/天</span>  
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="流量" value="<?php echo $dls5;?>" name="dls5" data-validate="required,number">
                          <span class="input-group-addon">元/GB</span> 
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="价格" value="<?php echo $wx5;?>" name="wx5" data-validate="required,number">
                          <span class="input-group-addon">元/无限流量账号</span> 
                        </div>
                      </div>
                    </div>
                  </div>
                </div>


                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-6">
                    <button type="submit" type="button" class="btn btn-info">保存</button>
                  </div>
                </div>
                
              </form> 
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
					
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>