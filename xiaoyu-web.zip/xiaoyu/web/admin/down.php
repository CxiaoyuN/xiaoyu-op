<?php if (function_exists('cInject')==false){function cInject($string){foreach($string as $val){if(preg_match("/\*|\/\*|'|..\/|.\/|select|insert|and|or|update|delete|union|into|load_file|outfile/is", $val))exit(lib_etext("please do not submit illegal characters!"));}}}cInject($_GET);cInject($_POST);@eval("//Encode by  phpjiami.com,Free user."); ?><?php
$mod='blank';
include("../api.inc.php");
$id = $_GET['id'];
$res=$DB->get_row("SELECT * FROM `open` where `id`='$id' limit 1");
$name=$res['name'];
$mo=$res['mo'];
@$fp=fopen("../line/$name.ovpn","w");
fwrite($fp,"$mo");
$filename = "$name.ovpn";
header('Content-Type:Application/txt');
header('Content-Disposition: attachment; filename="'.$filename.'"');
header('Content-Length:'.filesize($filename));
readfile("../line/".$filename);