<?php
$my = isset($_GET['my']) ? $_GET['my'] : null;
    if (!empty($_GET['kw'])) {
        $sql = " `name`='{$_GET['kw']}'";
        $numrows = $DB->count("SELECT count(*) from `auth_fwq` WHERE{$sql}");
        $con = ' ' . $numrows . ' ';
    } else {
        $numrows = $DB->count("SELECT count(*) from `auth_fwq` WHERE 1");
        $sql = " 1";
        $con = ' ' . $numrows . ' ';
    }
?>
<div class="row">
                                    <div class="col-xs-6">
                                        <a href="fwqlist.php" href="javascript:void(0)"   class="widget">
                                            <div class="widget-content themed-background-danger text-light-op text-center">
                                                <div class="widget-icon">
                                                    <i class="fa fa-database"></i>
                                                </div>
                                            </div>
                                            <div class="widget-content text-dark text-center">
                                                <h2 class="widget-heading h3 text-success">
                                            <strong><?php echo $con; ?></strong>
                                        </h2><br> 服务器数量
												
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xs-6">
                                        <a href="javascript:void(0)" class="widget">
                                            <div class="widget-content themed-background-dark text-light-op">
                                                <i class="fa fa-fw fa-chevron-right"></i> <strong><font><font>服务器监控</font></font></strong>
                                            </div>
                                            <div class="widget-content text-dark text-center" style="height: 170px; overflow: auto;">
                                                <table class="table table-striped table-borderless remove-margin">
                                                    <tbody>
                                          <?php
    $pagesize = 30;
    $pages = intval($numrows / $pagesize);
    if ($numrows % $pagesize) {
        $pages++;
    }
    if (isset($_GET['page'])) {
        $page = intval($_GET['page']);
    } else {
        $page = 1;
    }
    $offset = $pagesize * ($page - 1);
    $rs = $DB->query("SELECT * FROM `auth_fwq` WHERE{$sql} order by id desc limit $offset,$pagesize");
    while ($res = $DB->fetch($rs)) {
        $str = file_get_contents('http://' . $res['ipport'] . '/res/tcp.txt', false, stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
        $str2 = file_get_contents('http://' . $res['ipport'] . '/udp/udp.txt', false, stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
        $onlinenum_tcp = (substr_count($str, date('Y')) - 1) / 2;
        $onlinenum_udp = (substr_count($str2, date('Y')) - 1) / 2;
        $onlinenum = $onlinenum_tcp + $onlinenum_udp;
        if ($onlinenum < 0) $onlinetext = '<span style="color:red;">超时</span>';
        else $onlinetext = '<a href="online.php?id=' . $res['id'] . '">' . (int)$onlinenum . '</a>';
?>
                                          
                                           <tr>
                                          <td><a href="online.php?id=<?=$res['id'] ?>"><span><?=$res['name'] ?></span></a></td>
                                          <td><?=$onlinetext ?></td>
                                           </tr>
                                          <?php
    }
?>
                                      </tbody>
                                                </table>
                                            </div>
                                        </a>
                                    </div>
                                </div>