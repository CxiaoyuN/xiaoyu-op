

<?php
/**
 * 登录后台
 *
 */
 $title='后台管理系统';
error_reporting(E_ALL);
$mod = 'blank';
include ("../api.inc.php");
if (isset($_POST['user']) && isset($_POST['pass'])) {
    $user = daddslashes($_POST['user']);
    $pass = daddslashes($_POST['pass']);
    $pass = md5($pass);
    $row = $DB->get_row("SELECT * FROM `admin` limit 1");
	$new = $DB->get_row("SELECT * FROM `bfy_new` limit 1");
    if ($user == $row['username'] && $pass == $row['password']) {
        $session = md5($user . $pass . $password_hash);
        $token = authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
		if($new['info']==1){
			setcookie("ol_token", $token, time() + 604800);
        @header('Content-Type: text/html; charset=UTF-8');
        exit("<script language='javascript'>alert('登录成功！您还尚未激活线路，点击确认前往激活。');window.location.href='new.php';</script>");
		}elseif($new['info']==0){
        setcookie("ol_token", $token, time() + 604800);
        @header('Content-Type: text/html; charset=UTF-8');
        exit("<script language='javascript'>alert('登录成功！');window.location.href='index.php';</script>");
		}
    } elseif ($pass != $row['pass']) {
        @header('Content-Type: text/html; charset=UTF-8');
        exit("<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>");
    }
} elseif (isset($_GET['logout'])) {
    setcookie("ol_token", "", time() - 604800);
    @header('Content-Type: text/html; charset=UTF-8');
    exit("<script language='javascript'>alert('您已成功注销本次登录！');window.location.href='./login.php';</script>");
}
?>
<!doctype html>
<html lang="zh">
<head>
<?php
$rs=$DB->get_row("SELECT * FROM website");

$webtitle=$rs['title'];


?>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
<meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title><?php echo $webtitle ?> - <?php echo $title ?></title>
<link rel="stylesheet" type="text/css" href="../asset/login/styles.css">
</head>
<body  class="htmleaf-container">
<div class="htmleaf-container">
<script type="text/javascript">
                    jQuery(document).ready(function($)
                    {
                        // Reveal Login form
                        setTimeout(function(){ $(".fade-in-effect").addClass('in'); }, 1);
                        
                        
                        // Validation and Ajax action
                        $("form#login").validate({
                            rules: {
                                user: {
                                    required: true
                                },
                                
                                pass: {
                                    required: true
                                }
                            },
                            
                            messages: {
                                user: {
                                    required: '此为必填项！'
                                },
                                
                                pass: {
                                    required: '此为必填项！'
                                }
                            },
                            
                        });
                        
                        // Set Form focus
                        $("form#login .form-group:has(.form-control):first .form-control").focus();
                    });
                </script>
	<div class="wrapper">
		<div class="container">
		<form action="./login.php" method="post" role="form" id="login" class="login-form fade-in-effect">
			<b><h2><?php echo $webtitle ?> - <?php echo $title ?></h2><br></b>
			<form class="form">
				<input type="text" name="user" id="user" autocomplete="off" placeholder="Username">
				<input type="password" name="pass" id="pass" autocomplete="off" placeholder="Password">
				 
				<button type="submit">登录</button>
				
			</form>
			
		</div>
		
		<ul class="bg-bubbles">
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>
</div>
<script src="../asset/login/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
$('#login-button').click(function (event) {
	
	
		event.preventDefault();
		$('form').fadeOut(500);
		$('.wrapper').addClass('form-success');
		
	

});
</script>

</body>
</html>
