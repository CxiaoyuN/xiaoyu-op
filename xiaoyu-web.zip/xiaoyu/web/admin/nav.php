<?php
$url = $_SERVER['PHP_SELF'];
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
$count=$DB->count("SELECT count(*) from `openvpn` WHERE 1");
$count2=$DB->count("SELECT count(*) from `openvpn` WHERE i=1");
$countdaili=$DB->count("SELECT count(*) from `auth_daili` WHERE 1");
$countdaili2=$DB->count("SELECT count(*) from `auth_daili` WHERE active=0");
$countkm=$DB->count("SELECT count(*) from `auth_kms` WHERE 1");
$countkm2=$DB->count("SELECT count(*) from `auth_kms` WHERE isuse=0");
?>
                    <div id="sidebar">
                    <!-- Sidebar Brand -->
                    <div id="sidebar-brand" class="themed-background">
                        <a href="index.php" class="sidebar-title">
                            <i class="fa fa-cube"></i> <span class="sidebar-nav-mini-hide"><strong>小羽云控</strong></span>
                        </a>

                    </div>
                    <!-- END Sidebar Brand -->

                    <!-- Wrapper for scrolling functionality -->
                    <div id="sidebar-scroll">
                        <!-- Sidebar Content -->
                        <div class="sidebar-content">
                            <!-- Sidebar Navigation -->
                            <ul class="sidebar-nav">
                                <li>
                                    <a href="index.php" class=" active"><i class="gi gi-compass sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">平台首页</span></a>
                                </li>
                                <li class="sidebar-separator">
                                    <i class="fa fa-ellipsis-h"></i>
                                </li>
								 <li>
                                    <a href="../app_api/"><i class="gi gi-airplane sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">流量卫士后台</span></a>
                                </li>
                                <li>
                                    <a href="#" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="gi gi-more_items sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">服务管理</span></a>
                                    <ul>
                                        <li>
                                            <a href="addfwq.php">添加服务器</a>
                                        </li>
                                    
									 
                                        <li>
                                            <a href="fwqlist.php">服务器列表</a>
                                        </li>
                                    </ul>
                                </li>
								
								
								
								
								 <li>
                                    <a href="#" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="gi gi-inbox sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">帐号管理</span></a>
                                    <ul>
                                        <li>
                                            <a href="pladd.php">批量添加</a>
                                        </li>
                                    
                                        <li>
                                            <a href="addqq.php">添加帐号</a>
                                        </li>
                                    
                                        <li>
                                            <a href="qqlist.php">帐号列表</a>
                                        </li>
                                    </ul>
                                </li>
								
								
								
								
								
								 <li>
                                    <a href="#" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="gi gi-shopping_cart sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">商品管理</span></a>
                                    <ul>
                                        <li>
                                            <a href="kmtype.php">套餐管理</a>
                                        </li>
                                    
                                        <li>
                                            <a href="kmlist.php">商品列表</a>
                                        </li>
                                    
                                        <li>
                                            <a href="search.php">内容搜索</a>
                                        </li>
                                    </ul>
                                </li>
								
								
								
								
								
								 <li>
                                    <a href="#" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="fa fa-gift sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">代理管理</span></a>
                                    <ul>
                                        <li>
                                            <a href="daili.php">代理列表</a>
                                        </li>
                                   
                                        <li>
                                            <a href="dlkm.php">代理充值卡密</a>
                                        </li>
                                    
                                        <li>
                                            <a href="dlconfig.php">代理页面管理</a>
                                        </li>
                                    
                                        <li>
                                            <a href="cztype.php">代理充值管理</a>
                                        </li>
                                    </ul>
                                </li>
								
								
								
								
								
								
								
								
								 <li>
                                    <a href="#" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="gi gi-picture sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">官网管理</span></a>
                                    <ul>
                                        <li>
                                            <a href="weblist.php">分站管理</a>
                                        </li>
                                   
                                        <li>
                                            <a href="banner.php">图片管理</a>
                                        </li>
                                    
                                        <li>
                                            <a href="payset.php">支付宝对接</a>
                                        </li>
                                    </ul>
                                </li>
								
								
								
								
								
								
								
								 <li>
                                    <a href="#" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="fa fa-rocket sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">云端管理</span></a>
                                    <ul>
                                        
                                   
                                        <li>
                                            <a href="open.php">添加线路</a>
                                        </li>
                               
                                        <li>
                                            <a href="openlist.php">已有线路</a>
                                        </li>
										 <li>
                                            <a href="gg.php">公告设置</a>
                                        </li>
                                    </ul>
									
                                </li>
								
								
								
								
								
								 <li>
								 <a href="#" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="fa fa-share-alt sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">平台操作</span></a>
                                    <ul>
                                        <li>
                                            <a href="passwd.php">修改密码</a>
                                        </li>
                                 
                                        <li>
                                            <a href="log.php">操作记录</a>
                                        </li>
                               
                                        <li>
                                            <a href="online.php">在线用户</a>
                                        </li>
                               
                                        
                                    </ul>
                                
                            </ul>
                            <!-- END Sidebar Navigation -->

                            <!-- Color Themes -->
                            <!-- Preview a theme on a page functionality can be found in ../asset/js/app.js - colorThemePreview() -->
                            <div class="sidebar-section sidebar-nav-mini-hide">
                                
                                
                            </div>
                            <!-- END Color Themes -->
                        </div>
                        <!-- END Sidebar Content -->
                    </div>
                    <!-- END Wrapper for scrolling functionality -->

                    <!-- Sidebar Extra Info -->
                    <div id="sidebar-extra-info" class="sidebar-content sidebar-nav-mini-hide">
                        <div class="push-bit">
                            <span class="pull-right">
                                <a href="javascript:void(0)" class="text-muted"><i class="fa fa-plus"></i></a>
                            </span>
                            
                        </div>
                        
                        <div class="text-center">
                            
                            <small><span>2017</span> &copy; <a href="http://awayun.cn" target="_blank">小羽云控</a></small>
                        </div>
                    </div>
                    <!-- END Sidebar Extra Info -->
                </div>