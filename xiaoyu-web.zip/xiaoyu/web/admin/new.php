 <?php
$mod='blank';
include("../api.inc.php");
$title='当前在线用户';
$new = $DB->get_row("SELECT * FROM `bfy_new` limit 1");
if($islogin2==1){
	if($new['info']==0){
exit("<script language='javascript'>alert('您已激活过线路！如需重新激活，请前往数据库将bfy_new中的info更改成“1”，并清除浏览器缓存，后重新登录');window.location.href='login.php';</script>");}
else{}
}else exit("<script language='javascript'>window.location.href='./login.php';</script>");


?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
   
   
   
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
                    <!-- Page content -->
                    <div id="page-content">
					
 <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">默认信息</h3>
                      
                      
                    </div>
                    <div class="panel-body">
<?php
$bind_domain = explode(":",$_SERVER["HTTP_HOST"]);
if(isset($_POST['submit'])){
echo '<div class="alert '; 
$ip = $_REQUEST['ip']; 
$vpn = $_REQUEST['vpn']; 
$ca = $_REQUEST['ca']; 
$key = $_REQUEST['key'];   

  $DB->query("UPDATE open SET mo = REPLACE( mo,   '【ip】',  '$ip');");
  $DB->query("UPDATE open SET mo = REPLACE( mo,   '【port】',  '$vpn');");
  $DB->query("UPDATE open SET mo = REPLACE( mo,   '【证书】',  '$ca');");
  $DB->query("UPDATE open SET mo = REPLACE( mo,   '【key】',  '$key');");
  $DB->query("UPDATE line SET content = REPLACE( content,   '【ip】',  '$ip');");
  $DB->query("UPDATE line SET content = REPLACE( content,   '【port】',  '$vpn');");
  $DB->query("UPDATE line SET content = REPLACE( content,   '【证书】',  '$ca');");
  $DB->query("UPDATE line SET content = REPLACE( content,   '【key】',  '$key');");
  $DB->query("UPDATE bfy_new SET info = REPLACE( info,   '1',  '0');");
echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button><strong><h4>成功激活默认线路。</h4><br/>【如需重新激活，请前往数据库清空open，line表，分别导入默认线路包后，将数据库bfy_new中的info更改成“1”，并清除浏览器缓存，后重新登录】</strong></div>
                <a href="index.php" class="btn btn-info btn-icon btn-icon-standalone">
                  
                  <span>前往流控主页</span>
                </a>
<style>#newopen{display: none;}</style>'; }

?>
<!--textarea class="form-control" cols="5" id="field-5" rows="6" data-validate="required"><?php echo $key ?></textarea-->

                    <form id="newopen" action="./new.php" method="post" class="form-horizontal validate" role="form">
                      <div class="form-group">
                        <label class="col-sm-2 control-label">您的IP：</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" id="field-1" value="<?php echo $bind_domain[0] ?>" name="ip" data-validate="required">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="col-sm-2 control-label">VPN端口</label>
                        <div class="col-sm-2">
                                <label class="radio-inline">
                                  <input type="radio" name="vpn" value="440">
                                  440
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="vpn" checked="" value="443">
                                  443
                                </label>
                        </div>
                        <div class="col-sm-5">
                          <p class="text-info" style="line-height: 31px;">* 必须与搭建时候选择一致</p>
                        </div>
                      </div>  

                      <div class="form-group">
                        <label class="col-sm-2 control-label">您的证书：</label>
                        <div class="col-sm-9">
                           <textarea class="form-control" cols="5" id="field-5" name="ca" rows="6" data-validate="required"><?php
                                $myfile = fopen("../ca.crt", "r") or die("没有找到ca.crt");
                                echo fread($myfile,filesize("../ca.crt"));
                                fclose($myfile);
                                ?></textarea>
                        </div>
                      </div>  

                      <div class="form-group">
                        <label class="col-sm-2 control-label">您的Key：</label>
                        <div class="col-sm-9">
                           <textarea class="form-control" cols="5" id="field-5" name="key" rows="6" data-validate="required"><?php
                                $myfile = fopen("../ta.key", "r") or die("没有找到ta.key");
                                echo fread($myfile,filesize("../ta.key"));
                                fclose($myfile);
                                ?></textarea>
                        </div>
                      </div>  

                      <div class="form-group">
                        <label class="col-sm-2 control-label"></label>
                        <div class="col-sm-9">
                          <button type="submit"  name="submit" type="button" class="btn btn-info btn-block">立即激活默认线路</button>
                        </div>
                      </div>
                    </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
			
					
					<div class="row">
                        </div>
                      
                    </div>
                   
                </div>
               
            </div>
           
        </div>
        

       
        <script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
    </body>
</html>