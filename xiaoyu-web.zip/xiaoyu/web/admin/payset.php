<?php
$mod='blank';
include("../api.inc.php");
$title='支付宝对接';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>支付宝即时到账交易接口设置。</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					
					
					
					
					
					
					
					            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">接口配置输入</h3>
                      
                      
                    </div>
                    <div class="panel-body">

<?php
$id ='1';
if(!$id || !$row = $DB->get_row("select * from `alipay` where id='$id' limit 1")){ exit("不存在!");}
if($_POST['type']=="update"){
echo '<div class="alert ';
$partner = daddslashes($_POST['partner']);
$alikey = daddslashes($_POST['alikey']);
$url = daddslashes($_POST['url']);
  if($DB->query("update `alipay` set `partner`='$partner',`alikey`='$alikey',`url`='$url' where id='$id'")){
    echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改成功！';
  }else{
    echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改失败！'.$DB->error();
  }
echo '</div>';
echo "<style>#payset{display: none;}</style>";
//exit;
}
?>
      

                <form id="payset" action="./payset.php?id=<?=$id?>" method="post" role="form" class="form-horizontal">
                <input type="hidden" name="type" value="update" />

                  <div class="form-group">
                    <label class="col-sm-2 control-label">合作身份者ID</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" name="partner" data-validate="required,number,min[16]" value="<?=$row['partner']?>" placeholder="以2088开头由16位纯数字组成的字符串，">
                      <p class="text-success">查看地址：https://b.alipay.com/order/pidAndKey.htm</p>
                    </div>
                  </div>  

                  <div class="form-group">
                    <label class="col-sm-2 control-label">MD5密钥</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="alikey" data-validate="required,min[16]" value="<?=$row['alikey']?>" placeholder="由数字和字母组成的32位字符串">
                        <p class="text-success">查看地址：https://b.alipay.com/order/pidAndKey.htm</p>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">网站网址</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="url" data-validate="required" value="<?=$row['url']?>" placeholder="需www.abc.com格式的完整路径">
                        <p class="text-success">不能加?id=123这类自定义参数，必须外网可以正常访问</p>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-9">
                      <button type="submit" type="button" class="btn btn-info btn-block">设置</button>
                    </div>
                  </div>
                  
                </form>

                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>