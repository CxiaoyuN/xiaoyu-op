<?php
$mod='blank';
include("../api.inc.php");
$title='实时监控';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>此处可以进行实时流量日志查看</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					
					
					
					
					
					
					<div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">TCP协议日志明细</h3>
                      
                      
                    </div>
                    <div class="panel-body">
                      <div class="scrollable" data-max-height="500">
                      <?php
                      $myfile = fopen("../../../jiankong.log", "r") or die("Unable to open file!");
                      echo fread($myfile,filesize("../../../jiankong.log"));
                      fclose($myfile);
                      ?>
                      </div> 
                    </div>
                  
                  </div>

                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">UDP协议日志明细</h3>
                      
                      
                    </div>
                    <div class="panel-body">
                      <div class="scrollable" data-max-height="500">
                      <?php
                      $myfile = fopen("../../../jiankong-udp.log", "r") or die("Unable to open file!");
                      echo fread($myfile,filesize("../../../jiankong-udp.log"));
                      fclose($myfile);
                      ?>
                      </div> 
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
					
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>