<h2 class="widget-heading h3 text-success">
                                            <strong>当前版本</strong>
                                        </h2>
                                                <h3 class="text-dark"><strong>2.9</strong></h3><br>更新于：2017.07.20