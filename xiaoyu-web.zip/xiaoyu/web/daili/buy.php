<?php
$mod='blank';
include("../api.inc.php");
$title='账号列表';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">

<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12"><br>
                                          <h1 class="widget-heading h3 text-black"><strong>您好，代理<?php
$drs=$DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$user2=$drs['user'];
                             echo $user2;?>！<span class="label label-primary"><?php echo $v;?></span></strong></h1><br>
                                              
                                         
                                      </div>
									  
                                      
                                  </div>
                            </div>
					
					
					
					
					<div class="row">
              <div class="col-sm-12">               

                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">请选择充值面额</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">
                        <div id="addtype_list" class="row">
                                            <?php

                                            $rs=$DB->query("SELECT * FROM `kmtype` WHERE `i` = '1'");
                                            //$rs=$DB->query("SELECT * FROM `kmtype`");//读取全部套餐

                                            while($res = $DB->fetch($rs))
                                            { ?>
                                            <div class="col-sm-4">
                                              <div class="xe-widget xe-todo-list xe-todo-list-turquoise">
                                                <div class="xe-header">
                                                  <div class="xe-icon">
                                                    <i class="fa-credit-card"></i>
                                                  </div>
                                                  <div class="xe-label">
                                                    <strong><?=$res['name']?></strong>
                                                  </div>
                                                </div>
                                                <div class="xe-body">
                                                  
                                                  <ul class="list-unstyled">
                                                    <li>
                                                      <label>
                                                        <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked=""></div><div class="cbr-state"><span></span></div></div>
                                                        <span><?=$res['km_rmb']?>元</span>
                                                      </label>
                                                    </li>
                                                  </ul>
                                                  
                                                </div>
            <?php
              /*获取支付宝*/
              $alpay= $DB->get_row("SELECT * FROM alipay");
              $alpay_on=$alpay['partner'];
$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao=$config['gg'];//公告获取
$shopUrl=$config['shopUrl'];//购买链接
              if($alpay_on<>""){
                $bay_btn="<a href=pay.php?id=".$res['id']." type='submit' class='btn btn-white btn-single btn-block'>立即充值</a>";
              }
              else{
                  $bay_btn="<a href=".$shopUrl." target='_blank' type='submit' class='btn btn-white btn-single btn-block'>立即充值</a>";
              }
            ?>
                                                <div class="xe-footer">
                                                         <?php echo $bay_btn; ?>
                                                </div>
                                              </div>
                                            </div>

                                            <?php }
            /*if($rs){

            }else{
              echo '<div class="col-sm-12"><div class="alert alert-white">
                                                    <button type="button" class="close">
                                                        <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                    暂无套餐可购买！
                  </div></div>';
            }*/
                                            ?>


                        </div>
                      
                    </div>
                  
                  </div>
              </div>
            </div>
					
					
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	 <script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        
    </body>
</html>