
                    <div id="sidebar">
                    <!-- Sidebar Brand -->
                    <div id="sidebar-brand" class="themed-background">
                        <a href="index.php" class="sidebar-title">
                            <i class="fa fa-cube"></i> <span class="sidebar-nav-mini-hide"><strong><?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?></strong></span>
                        </a>

                    </div>
                    <!-- END Sidebar Brand -->

                    <!-- Wrapper for scrolling functionality -->
                    <div id="sidebar-scroll">
                        <!-- Sidebar Content -->
                        <div class="sidebar-content">
                            <!-- Sidebar Navigation -->
                            <ul class="sidebar-nav">
                                <li>
                                    <a href="index.php" class=" active"><i class="gi gi-compass sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">代理首页</span></a>
                                </li>
                                <li class="sidebar-separator">
                                    <i class="fa fa-ellipsis-h"></i>
                                </li>
								 <li>
                                    <a href="qqlist.php"><i class="gi gi-shop_window sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">用户查看</span></a>
                                </li>
								
								
								<li>
                                    <a href="kmtype.php"><i class="si si-apple sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">套餐管理</span></a>
                                </li>
                                
						
								<li>
                                    <a  href="kmlist.php"><i class="si si-android sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">商品列表</span></a>
                                </li>
								
								
								<li>
                                    <a href="wx.php"><i class="gi gi-circle_exclamation_mark sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">包月无限</span></a>
                                </li>
								<li>
                                    <a href="linelist.php"><i class="gi gi-circle_exclamation_mark sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">线路下载</span></a>
                                </li>
							
								
								<li>
                                    <a href="sale.php"><i class="gi gi-circle_exclamation_mark sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">我的推广</span></a>
                                </li>
								
								<li>
                                    <a  href="search.php"><i class="gi gi-circle_exclamation_mark sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">搜素内容</span></a>
                                </li>
								<li>
                                    <a href="dlinfo.php"><i class="gi gi-circle_exclamation_mark sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">信息设置</span></a>
                                </li>
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
                                
                            </ul>
                            <!-- END Sidebar Navigation -->

                            <!-- Color Themes -->
                            <!-- Preview a theme on a page functionality can be found in ../asset/js/app.js - colorThemePreview() -->
                            <div class="sidebar-section sidebar-nav-mini-hide">
                                
                                
                            </div>
                            <!-- END Color Themes -->
                        </div>
                        <!-- END Sidebar Content -->
                    </div>
                    <!-- END Wrapper for scrolling functionality -->

                    <!-- Sidebar Extra Info -->
                    <div id="sidebar-extra-info" class="sidebar-content sidebar-nav-mini-hide">
                        <div class="push-bit">
                            <span class="pull-right">
                                <a href="javascript:void(0)" class="text-muted"><i class="fa fa-plus"></i></a>
                            </span>
                            
                        </div>
                        
                        <div class="text-center">
                            
                            <small><span>2017</span> &copy; <a href="../web/" target="_blank"><?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?></a></small>
                        </div>
                    </div>
                    <!-- END Sidebar Extra Info -->
                </div>