<?php
/**
 * 搜索授权
**/
$mod='blank';
include("../api.inc.php");
$title='搜索卡密';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">

<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12"><br>
                                          <h1 class="widget-heading h3 text-black"><strong>您好，代理<?php
$drs=$DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$user2=$drs['user'];
                             echo $user2;?>！<span class="label label-primary"><?php echo $v;?></span></strong></h1><br>
                                              
                                         
                                      </div>
									  
                                      
                                  </div>
                            </div>
					
					
					
					
					
					
					<div class="row">
                
                <div class="col-sm-12">
                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            请输入信息
                        </div>
                        
                        <div class="panel-body">
                            
                            <div class="row">
                                <div class="col-sm-12">
                                    
                              <form action="./kmlist.php" method="get" class="form-inline validate" role="form">
                                <div class="form-group">
                                  <select name="type" class="form-control">
                                    <option value="1">卡密</option>
                                    <option value="2">账号</option>
                                  </select>
                                </div>
                                <div class="form-group">
                                  <input type="text" name="kw" value="" class="form-control"  data-validate="required"/>
                                </div>
                                <input type="submit" value="查询" class="btn btn btn-secondary btn-info"/>
                              </form>
                                    
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

            </div>
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	 <script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        
    </body>
</html>