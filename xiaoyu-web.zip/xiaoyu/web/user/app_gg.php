
<?php
// 数据库连接
include ("../api.inc.php");
if (isset($_GET['id'])) {
    $n = daddslashes($_GET['id']);
    $rs = $DB->get_row("SELECT * FROM bfy_gg WHERE `id`=1 limit 1");
    if (!$rs) {
        echo '公告获取失败';
    } else {
        echo $rs[$n];
    }
}
?>