 <head>
        <meta charset="utf-8">

        <title><?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?> - 流量平台</title>

        <meta name="description" content="小羽云控">
        <meta name="author" content="pixelcave">
        <meta name="robots" content="noindex, nofollow">

        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <link rel="shortcut icon" href="../asset/img/favicon.png">
        <link rel="apple-touch-icon" href="../asset/img/icon57.png" sizes="57x57">
        <link rel="apple-touch-icon" href="../asset/img/icon72.png" sizes="72x72">
        <link rel="apple-touch-icon" href="../asset/img/icon76.png" sizes="76x76">
        <link rel="apple-touch-icon" href="../asset/img/icon114.png" sizes="114x114">
        <link rel="apple-touch-icon" href="../asset/img/icon120.png" sizes="120x120">
        <link rel="apple-touch-icon" href="../asset/img/icon144.png" sizes="144x144">
        <link rel="apple-touch-icon" href="../asset/img/icon152.png" sizes="152x152">
        <link rel="apple-touch-icon" href="../asset/img/icon180.png" sizes="180x180">
        <link rel="stylesheet" href="../asset/css/bootstrap.min.css">
        <link rel="stylesheet" href="../asset/css/plugins.css">
        <link rel="stylesheet" href="../asset/css/main.css">
        <link rel="stylesheet" href="../asset/css/themes.css">
        <script src="../asset/js/vendor/modernizr-3.3.1.min.js"></script>
    </head>