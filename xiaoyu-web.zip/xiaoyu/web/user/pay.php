<?php
$mod='blank';
include("../api.inc.php");

$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
if(!$res){
//	header('location: login.php');
		exit("<script language='javascript'>alert('未正确登录，或用户名或密码不正确！');window.location.href='/user/login.php';</script>");
}

/*获取代理信息*/
$daili_info = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
$daili_info_id=$daili_info['dlid'];
//echo "<script language='javascript'>alert('获取代理信息：".$daili_info_id."');</script>";

if($daili_info_id){
	$config_dl = $DB->get_row("SELECT * FROM auth_daili WHERE id='$daili_info_id' limit 1");
	$config_name=$config_dl['name'];//代理姓名
	$config_qq=$config_dl['qq'];
	$config_tel=$config_dl['tel'];
	$config_buy=$config_dl['buy'];//购买链接
	$config_buy2=$config_dl['buy2'];//购买代码
	//echo "<script language='javascript'>alert('获取代理信息：".$config_name."');</script>";
}else{
	$rs=$DB->get_row("SELECT * FROM website");
	$config_name=$rs['title'];
	$config_qq=$rs['qq'];
	$config_tel=$rs['tel'];

	$rs2=$DB->get_row("SELECT * FROM auth_config");
	$config_buy=$rs2['shopUrl'];
	$config_buy2=$rs2['shopCode'];
}


    //获取套餐信息：
    $id = daddslashes($_GET['id']);
    $kmtype=$DB->get_row("SELECT * FROM `kmtype` WHERE `id` = $id");
    $kmtype_name = $kmtype['name'];
    $kmtype_rmb = $kmtype['km_rmb'];
    //$kmtype_rmb = '0.01';//调试价格

?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                         <br> <h1 class="widget-heading h3 text-black"><strong><?php echo "您好，".$res['iuser'];?>！<?=($res['i']?'</strong><div class="btn btn-success m-t-10">账号正常</div>':'<div class="btn btn-danger m-t-10">账号禁用</div>')?></h1>
                                             <br>
                                      </div> 
                                  </div>
                            </div>
							<div class="widget-content widget-content-mini themed-background-muted">
					
			
					
					<div class="row">
					
				<div class="col-sm-12">
													
					<h5>订单信息：</h5>

					<form action="/pay/alipayapi.php" class="alipayform" method="post" target="_blank">
					<ul class="list-group list-group-minimal">
						<li class="list-group-item">
							<?php
							$d=time();
							?>
							<span class="badge badge-roundless badge-warning"><?php echo "" . date("Ymdhis", $d);?></span>
							<input type="text" name="WIDout_trade_no" id="out_trade_no" value="<?php echo "" . date("Ymdhis", $d);?>" class="hide">
							订单号
						</li>
						<li class="list-group-item">
							<span class="badge badge-roundless badge-info"><?php echo $kmtype_name?></span>
							<input type="text" name="WIDsubject" value="<?php echo $kmtype_name?>" class="hide">
							商品名称
						</li>
						<li class="list-group-item">
							<span class="badge badge-roundless badge-danger"><?php echo $kmtype_rmb?></span>
							<input type="text" name="WIDtotal_fee" value="<?php echo $kmtype_rmb?>" class="hide">
							付款金额
						</li>
						<input type="text" name="WIDbody" value="<?php echo $u?>" class="hide">
					</ul>
					<button type="submit" class="btn btn-success btn-icon btn-block">
						<i class="fa-check"></i>
						<span>确认支付</span>
					</button>
					<a href="javascript:history.go(-1)" type="submit" class="btn btn-white btn-icon btn-block">
						<i class="fa-reply"></i>
						<span>重选套餐</span>
					</a>
					</form>
					
				</div>

			</div>
					

					
					
					
					
					
					
					
					
					      </div>
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>