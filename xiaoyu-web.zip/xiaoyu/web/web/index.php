
<!DOCTYPE html>
<html lang="en">
<?php
/**
 * 网站首页
**/
$mod='blank';
include("../api.inc.php");
$title='网站首页';
?>
<?php include 'head.php';?>
<body   data-spy="scroll" data-target="#topnav"  id="top">

    <section class="header-area-home" id="header-area-home">
        <?php include 'nav.php';?>
		
		
		
        <div id="featured-slider-container">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div id="featured-slider" class="carousel slide" data-ride="carousel">
                            <!-- Indicators -->
                            <ol class="carousel-indicators">
                                <li data-target="#featured-slider" data-slide-to="0" class="active"><img src='imgs/slider-1-t.jpg' alt='' class='featured-slide-thumb'  /></li>
                                <li data-target="#featured-slider" data-slide-to="1" ><img src='imgs/slider-2-t.jpg' alt='' class='featured-slide-thumb'  /></li>
                                <li data-target="#featured-slider" data-slide-to="2" ><img src='imgs/slider-3-t.jpg' alt='' class='featured-slide-thumb'  /></li>
                            </ol>

                            <!-- Wrapper for slides -->
                            <div class="carousel-inner" role="listbox">
                                <div class="item active" id="slide-2">
                                    <img src='imgs/slider-1.jpg' alt='' class='featured-slide inv' data-animation = 'animated zoomIn' data-delay = '0.3s' />
                                    <img src='imgs/slider-2.jpg' alt='' class='featured-slide featured-slide-1 inv' data-animation = 'animated zoomIn' data-delay = '0.7s' />
                                    <div class="carousel-caption">
                                        <span class="lead slide-cat inv"  data-animation="animated zoomIn"><a href="#" rel="category">免费体验</a></span>
                                        <h2 class="slide-title inv"  data-animation="animated fadeInUp" data-duration="2s" data-delay="1s">现在马上注册，获得<?php echo $reg_cash_con ?>免费体验</h2>
                                        <div class="slide-excerpt inv" data-animation="animated fadeInUp" data-duration="3s" data-delay="2s">
                                            <ul class="row">
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2s'>苹果/安卓全机型兼容，坚持领先一步</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.1s'>有信号的地方即可使用，速度极快</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.2s'>网络轻松提升，轻松上5M/s</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.3s'>只需要账号和密码，轻松登录即可</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.4s'>提供会员中心查询流量，充值服务</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.5s'>低价服务，坚决抵制高额流量费</li>

                                            </ul>
                                        </div>
                                        <div class="meta">
                                          <a target="_blank" href="/user/reg.php">  <button  class="btn btn-primary inv slide-btn btn-lg"  data-animation="animated fadeInUp" data-delay="3s" data-duration="2s">马上注册 <i class="tn-arrow-right"></i></button></a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item" id="slide-3">
                                    <img src='imgs/slider-2.jpg' alt='' class='featured-slide inv' data-animation = 'animated zoomIn' data-delay = '0.3s' />
                                    <img src='imgs/slider-3.jpg' alt='' class='featured-slide featured-slide-1 inv' data-animation = 'animated zoomIn' data-delay = '0.7s' />
                                    <div class="carousel-caption">
                                        <span class="lead slide-cat inv"  data-animation="animated zoomIn"><a href="#" rel="category"><?php echo $tit3 ?></a></span>
                                        <h2 class="slide-title inv"  data-animation="animated fadeInUp" data-duration="2s" data-delay="1s"><?php echo $info3 ?></h2>
                                        <div class="slide-excerpt inv" data-animation="animated fadeInUp" data-duration="3s" data-delay="2s">
                                            <ul class="row">
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2s'>苹果/安卓全机型兼容，坚持领先一步</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.1s'>有信号的地方即可使用，速度极快</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.2s'>网络轻松提升，轻松上5M/s</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.3s'>只需要账号和密码，轻松登录即可</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.4s'>提供会员中心查询流量，充值服务</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.5s'>低价服务，坚决抵制高额流量费</li>

                                            </ul>
                                        </div>
                                        <div class="meta">
                                            <a href="and.php"><button class="btn btn-info inv slide-btn btn-lg"  data-animation="animated lightSpeedIn" data-delay="3s" data-duration="2s">安卓使用教程<i class="tn-arrow-right"></i></button></a>
                                        </div>

                                    </div>
                                </div>
                                <div class="item" id="slide-4">
                                    <img src='imgs/slider-3.jpg' alt='' class='featured-slide inv' data-animation = 'animated zoomIn' data-delay = '0.3s' />
                                    <img src='imgs/slider-1.jpg' alt='' class='featured-slide featured-slide-1 inv' data-animation = 'animated zoomIn' data-delay = '0.7s' />
                                    <div class="carousel-caption">
                                        <span class="lead slide-cat inv"  data-animation="animated zoomIn"><a href="#" rel="category"><?php echo $tit2 ?></a></span>
                                        <h2 class="slide-title inv"  data-animation="animated fadeInUp" data-duration="2s" data-delay="1s"><?php echo $info2 ?></h2>
                                        <div class="slide-excerpt inv" data-animation="animated fadeInUp" data-duration="3s" data-delay="2s">
                                            <ul class="row">
                                               <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2s'>苹果/安卓全机型兼容，坚持领先一步</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.1s'>有信号的地方即可使用，速度极快</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.2s'>网络轻松提升，轻松上5M/s</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.3s'>只需要账号和密码，轻松登录即可</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.4s'>提供会员中心查询流量，充值服务</li>
                                                <li class="col-lg-6" data-animation = 'animated zoomIn' data-delay = '2.5s'>低价服务，坚决抵制高额流量费</li>

                                            </ul>
                                        </div>
                                        <div class="meta">
                                           <a href="ios.php"> <button class="btn btn-danger inv slide-btn btn-lg"  data-animation="animated fadeInUp" data-delay="3s" data-duration="2s">苹果使用教程<i class="tn-arrow-right"></i></button></a>
                                        </div>

                                    </div>
                                </div>

                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <section class="featured-content-area" id="featured-content-area">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="panel panel-success panel-featured-content  text-center">
                        <div class="panel-heading">联系我们</div>
                        <div class="panel-body">
                            <div class="  wow zoomIn" data-wow-delay="500ms">
                            <strong><span><br><br>QQ:<?php echo $qq?><br><br><br><br><br><br><br></span></strong>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
				<a href="../user/login.php">
                    <div class="panel panel-info panel-featured-content  text-center">
                        <div class="panel-heading">注册/登录</div>
                        <div class="panel-body">
                            <div class="diamond filled bg-info wow zoomIn" data-wow-delay="900ms" >
                                <i class="lineicon tn-world"></i>
                            </div>

                        </div>
                    </div>
					</a>
                </div>
                <div class="col-md-3">
				<a href="and.php">
                    <div class="panel panel-primary panel-featured-content  text-center">
                        <div class="panel-heading">安卓使用</div>
                        <div class="panel-body">
                            <div class="diamond filled  bg-primary wow zoomIn" data-wow-delay="1300ms" >
                                <i class="lineicon tn-android"></i>
                            </div>

                        </div>
                    </div>
					</a>
                </div>
                <div class="col-md-3">
				<a href="ios.php">
                    <div class="panel panel-warning panel-featured-content  text-center">
                        <div class="panel-heading">苹果使用</div>
                        <div class="panel-body">
                            <div class="diamond filled bg-warning wow zoomIn" data-wow-delay="1700ms" >
                                <i class="lineicon tn-apple"></i>
                            </div>

                        </div>
                    </div>
					</a>
                </div>
            </div>
        </div>
    </section>
    <section class="why-us" id="why-us">

        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center section-intro">
                    <h2 class="header-boxed wow zoomIn" data-wow-iteration="1"><span>为什么选择我们？</span></h2>
                    <p class="lead wow fadeInUp"  data-wow-delay="600ms">简单而唯一的原因，我们是最好的！让我们看看一些亮点：</p>
                </div>
                <div class="col-md-12 highlight-boxes">
                <div class="col-md-4 wow fadeInLeft" data-wow-delay="500ms">
                    <div class="featured-content-box text-center">
                        <i class="tn-heart ico-lg text-warning"></i>

                        <h3><?php echo $webtitle ?></h3>
                        <p>聊QQ，聊微信，刷探探，<br/>流量免了！</p>
                        
                    </div>
                </div>
                
                
                    
                    <div class="col-md-4 wow fadeInUp" data-wow-delay="300ms">
                        <div class="featured-content-box text-center">
                            <i class="tn-headphone ico-lg text-warning"></i>

                            <h3><?php echo $webtitle ?></h3>
                            <p>听音乐，看电影，还需要担心流量问题？流量免了！</p>
                            
                        </div>
                    </div>
                    <div class="col-md-4 wow fadeInUp" data-wow-delay="600ms">
                        <div class="featured-content-box text-center">
                            <i class="tn-dashboard ico-lg text-info"></i>

                            <h3><?php echo $webtitle ?></h3>
                            <p>王者荣耀，龙之谷，穿越火线..游戏算什么？流量免了！</p>
                            
                        </div>
                    </div>
                </div>


            </div>
        </div>

    </section>

    

   
    </section>


    <section class="client-reviews" id="client-reviews">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center section-intro">
                    <h2 class="header-boxed wow zoomIn" data-wow-iteration="1"><span>常见问题</span></h2>
                    
                </div>

                <div class="col-md-4">
                    <div class="speach"><strong>为什么可以免流？</strong><br/><br/>
                        每实际使用1G流量仅扣几M套餐内流量，通过客户端使用的云节流功能，从而实现随时随地无限免费流量上网！
                        <div class="media person">
                            <div class="pull-left">
                                
                            </div>
                            <div class="media-body">
                                
                            </div>
                        </div>
                    </div>
                </div>
				<div class="col-md-4">
                    <div class="speach"><strong>请问有什么注意事项？</strong><br/><br/>
                       1、关闭你的wifi，开启你的手机流量数据，把所有正在运行的软件都关闭<br>2、如果手机双卡双待，请切换到您用来上网的手机卡。<br>3、不支持手机开热点。
                        <div class="media person">
                            <div class="pull-left">
                                
                            </div>
                            <div class="media-body">
                                
                            </div>
                        </div>
                    </div>
                </div>

                
				
				
				<div class="col-md-4">
                    <div class="speach"><strong>账号正常，连接时却一直连接不上</strong><br/><br/>
                        A、可能由于服务器连接过于频繁，请关闭软件重新登录重新连接即可<br>
							B、可能你的手机CPU过热，重启你的手机然后重新登录重新连接即可<br>
							C、可能是我们的服务器出现问题了，停止使用然后联系客服即可<br>
							D、每个地区所用线路不一样，使用过程中发现会扣掉自身流量套餐的流量，尝试更改手机网络接入点改为wap或者net试一下
                        <div class="media person">
                            <div class="pull-left">
                                
                            </div>
                            <div class="media-body">
                                
                            </div>
                        </div>
                    </div>
                </div>
				<div class="col-md-4">
                    <div class="speach"><strong>为什么有时候断线连接不上？</strong><br/><br/>
                        A、由于4G手机数据和通话不在一个网络模式下的原因，用户在接打电话是会断开数据通信，所以在通话之后，需要重新连接软件，然后再继续上网；<br>B、锁屏熄屏或者手机清理后台都有可能造成软件掉线，从而不能使用<?php echo $webtitle ?>；<br>C、用户在观看视频的同时请留意屏幕左上角的小钥匙是否还显示，以防掉线完全消耗你自身的流量，具体消耗比例以测试为准。
                        <div class="media person">
                            <div class="pull-left">
                                
                            </div>
                            <div class="media-body">
                                
                            </div>
                        </div>
                    </div>
                </div>
				<div class="col-md-4">
                    <div class="speach"><strong>使用本软件为什么会消耗本机流量？</strong><br/><br/>
                        A、本软件在每次登陆或者连接时可能需要损耗50K左右手机套餐流量，手机自带的软件在后台运行会消耗少量流量。<br>
							B、在使用过程中如果遇到掉线又重新连接，掉线重新连接需要一定的时间。<br>
							C、本软件在部分城市存在盲区包括个别手机品牌型号不能兼容导致不能使用，首次使用时一定要先做测试，确认不会消耗你手机流量套餐的流量后再继续使用。
                        <div class="media person">
                            <div class="pull-left">
                                
                            </div>
                            <div class="media-body">
                                
                            </div>
                        </div>
                    </div>
                </div>
				
				<div class="col-md-4">
                    <div class="speach"><strong>软件在使用的过程中会发生掉线？</strong><br/><br/>
                       A、拨打电话时，手机网络会自行中断，通话完成之后软件会自动重新连接，可能有部分手机需要手动重新连接软件。<br>
							B、部分手机自带一键清理功能，或者安装360，手机管家，手机助手等此类软件，请将流量库设置为白名单，可以避免部分掉线问题<br>
							C、请不要随便恢复手机出厂设置，也不要随便清理手机数据，由此造成的损失自行承担。
                        <div class="media person">
                            <div class="pull-left">
                                <br/>
                            </div>
                            <div class="media-body">
                                
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <section class="pricing" id="pricing">
    <div class="container">
    <div class="row">
    <div class="col-md-12 text-center section-intro">
        <h2 class="header-boxed  wow zoomIn" data-wow-iteration="1"><span>价格</span></h2>
        <p class="lead wow fadeInUp" data-wow-delay="200ms">是否已经心动不已？马上合作加盟吧！</p>
    </div>

    <div class="col-md-12">
        <div class="col-md-6 pricing-table-block wow fadeInLeft">
            <div class="col-md-6 tb-left text-center">
                <h5 class="text-success">流量体验</h5>
                <h3>￥<?php echo $jia1;?>元</h3>
                <p><i class="tn-star  text-info"></i><i class="tn-star  text-info"></i><i class="tn-star text-info"></i><i class="tn-star text-info"></i><i class="tn-star text-info"></i></p>
                <br>
               <a href="../user/reg.php"><button class="btn btn-success">立即注册</button></a>
            </div>
			<div class="col-md-6 tb-right">
                <ul class="list-group"><br>
                     <h3><p class="pac-info text-center text-success">注册新用户赠送<?php echo $reg_cash_con ?>提供测试<br><br><br><?php echo $user_endtime_con ?>天免费体验</p><h3>
                    
                    
                </ul>
            </div>
            
        </div>
		
		
		
		<div class="col-md-6 pricing-table-block wow fadeInLeft">
            <div class="col-md-6 tb-left text-center">
                <h5 class="text-success">按量计费</h5>
                <h3>￥<?php echo $jia2;?>元起</h3>
                <p><i class="tn-star  text-info"></i><i class="tn-star  text-info"></i><i class="tn-star text-info"></i><i class="tn-star text-info"></i><i class="tn-star text-info"></i></p>
                <br>
               <a href="tencent://message/?uin=<?php echo $qq?>&Site=junjiecaiwu&Menu=yes"> <button class="btn btn-success">立即订购</button></a>
            </div>
			<div class="col-md-6 tb-right">
                <ul class="list-group"><br>
                     <h3><p class="pac-info text-center text-success">流量自由分配按需求订购，不限制速度与时间<br>多种套餐特惠<br>可以顺延升级</p><h3>
                    
                    
                </ul>
            </div>
            
        </div>
		
		<div class="col-md-6 pricing-table-block wow fadeInLeft">
            <div class="col-md-6 tb-left text-center">
                <h5 class="text-success">包月计费</h5>
                <h3>￥<?php echo $jia3;?>元</h3>
                <p><i class="tn-star  text-info"></i><i class="tn-star  text-info"></i><i class="tn-star text-info"></i><i class="tn-star text-info"></i><i class="tn-star text-info"></i></p>
                <br>
                <a href="tencent://message/?uin=<?php echo $qq?>&Site=junjiecaiwu&Menu=yes"><button class="btn btn-success">立即订购</button></a>
            </div>
			<div class="col-md-6 tb-right">
                <ul class="list-group"><br>
                     <h3><p class="pac-info text-center text-success">适合每月无限流量轻松上网看视频和网页较多用户<br><br>有网就看<br>续费有送</p><h3>
                    
                    
                </ul>
            </div>
            
        </div>
		<div class="col-md-6 pricing-table-block wow fadeInLeft">
            <div class="col-md-6 tb-left text-center">
                <h5 class="text-success">加盟合作</h5>
                <h3>￥<?php echo $jia4;?>元起</h3>
                <p><i class="tn-star  text-info"></i><i class="tn-star  text-info"></i><i class="tn-star text-info"></i><i class="tn-star text-info"></i><i class="tn-star text-info"></i></p>
                <br>
                <a href="tencent://message/?uin=<?php echo $qq?>&Site=junjiecaiwu&Menu=yes"><button class="btn btn-success">立即加盟</button></a>
            </div>
			<div class="col-md-6 tb-right">
                <ul class="list-group"><br>
                     <h3><p class="pac-info text-center text-success">独立代理平台，可以自由组合套餐，手机都可以开卡<br>分级别代理，优惠提流量<br>每周更新促销活动</p><h3>
                    
                    
                </ul>
            </div>
            
        </div>
		
		
		
		
		
		
		
        
        </div>
    </div>

    </div>
    </div>
    </section>

   

    <?php include 'footer.php';?>



<script src="js/jquery-2.1.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.sticky.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/site.js"></script>

</body>
</html>