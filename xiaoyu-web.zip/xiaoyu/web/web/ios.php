<!DOCTYPE html>
<html lang="en">
<?php
/**
 * 网站首页
**/
$mod='blank';
include("../api.inc.php");
$title='IOS系统安装流程（旧版）';
?>
<?php include 'head.php';?>
<body   data-spy="scroll" data-target="#topnav"  id="top">

    <section class="header-area-home" id="header-area-home">
        <?php include 'nav2.php';?>
		<section class="header-area-home" id="header-area-home">
        		
		
		
        <div id="featured-slider-container">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div id="featured-slider" class="carousel slide" data-ride="carousel">
                            
							
							<section class="pricing" id="pricing">
    <div class="container">
    <div class="row">
    <div class="col-md-12 text-center section-intro">
        <h2 class="header-boxed  wow zoomIn animated" data-wow-iteration="1" style="visibility: visible; animation-iteration-count: 1; animation-name: zoomIn;"><span>IOS系统安装流程（旧版）</span></h2>
		
		<br>
		<a href="ios2.php?name=" class="btn btn-primary btn-sm" target="_blank">xy苹果助手安装（新版）</a>&nbsp;&nbsp;&nbsp;<a href="http://cloud.video.taobao.com/play/u/278335198/p/1/e/6/t/1/47716425.mp4" class="btn btn-primary btn-sm" target="_blank">视频教程（旧版）</a>
		<br><br>
		<p class="lead wow fadeInUp text-success animated" data-wow-delay="200ms" style="visibility: visible; animation-delay: 200ms; animation-name: fadeInUp;">苹果手机仅需4步即可完成软件安装，微信浏览请点击右上方“...”在Safari打开播放视频</p>
		
		
    </div>
	
	
	
	

    <div class="col-md-12">
        <div class="col-md-6 pricing-table-block wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
		<div class="col-md-6 tb-right">
                <ul class="list-group"><br>
				<h3><p class="pac-success text-center text-success">①<br><br>进入“手机设置”</p></h3><h3>
                     
                </h3></ul>
				<span>
							<p>
								帐号：<?php echo $appleid1 ?><br>
								密码：<?php echo $appleps1 ?><br><br>
								帐号：<?php echo $appleid2 ?><br>
								密码：<?php echo $appleps2 ?><br><br>
								帐号：<?php echo $appleid3 ?><br>
								密码：<?php echo $appleps3 ?><br><br>
							</p>

							<p><b>* 该ID仅提供登陆App Store商店下载应用，请下载完成后退出此ID！</b></p></span>
            </div>
            <div class="col-md-6 tb-left text-center">
               
				<img src="images/ios_03.jpg" width="240">
                
                
            </div>
			
            
        </div>
		
		<div class="col-md-6 pricing-table-block wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
		<div class="col-md-6 tb-right">
                <ul class="list-group"><br>
				<h3><p class="pac-success text-center text-success">②<br><br>下载“OpenVPN”</p></h3><h3>
                     
                </h3></ul>
				<span>
							<p>如出现无法搜索空白页面，请稍作等待；<br>
							该软件无法下载或者遇到问题，请联系代理商；<br><br><br><br><br><br></p>
							<p><b>* 该ID仅提供登陆App Store商店下载应用，请下载完成后退出此ID！</b></p>
							<p><a href="#" class="btn btn-primary btn-sm hide">Learn more</a></p>
							</span>
            </div>
            <div class="col-md-6 tb-left text-center">
               
				<img src="images/ios_07.jpg" width="240">
                
                
            </div>
			
            
        </div>
		
		
		<div class="col-md-6 pricing-table-block wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
		<div class="col-md-6 tb-right">
                <ul class="list-group"><br>
				<h3><p class="pac-success text-center text-success">③<br><br>加载“<?php echo $webtitle ?>”<br>.</p></h3><h3>
                     
                </h3></ul>
				<span>
							<p>登录<a target="_blank" href="/user/login.php">会员中心</a>下载线路，选择Openvpn打开；<br>
							输入帐号和密码，未注册请联系代理商；</p>
							<p><a href="#" class="btn btn-primary btn-sm hide">Learn more</a></p></span>
            </div>
            <div class="col-md-6 tb-left text-center">
               
				<img src="images/ios_11.jpg" width="240">
                
                
            </div>
			
            
        </div>
		
		
		<div class="col-md-6 pricing-table-block wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
		<div class="col-md-6 tb-right">
                <ul class="list-group"><br>
				<h3><p class="pac-success text-center text-success">④<br><br>检测是否使用“<?php echo $webtitle ?>”？</p></h3><h3>
                     
                </h3></ul>
				<span>
							<p>1，连接成功后，先查询自己流量剩余多少；<br>
							2，刷刷朋友圈，瞧瞧小新闻，看看小视频</p>
							</span>
            </div>
            <div class="col-md-6 tb-left text-center">
               
				<img src="images/ios_13.jpg" width="240">
                
                
            </div>
			
            
        </div>
		
		
		<p class="pac-success text-center text-success">
		<br><br>
		<a href="sms:10086?body=cxll" class="btn btn-primary btn-sm">移动-查询流量</a>
		<a href="sms:10010?body=cxll" class="btn btn-primary btn-sm">联通-查询流量</a>
		<br>
		<b>* 过20分钟后点上面“查询流量”如果只是使用了几KB，即成功使用免流</b></p>
		
		
		
		
		
		
        
        </div>
    </div>

    </div>
    </section>
							
							
	










	
	
	</div></div></div></div></div>
	</section>

    </section>
	
   <?php include 'footer.php';?>

    


<script src="js/jquery-2.1.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.sticky.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/site.js"></script>


<div id="cntvlive2-is-installed"></div></body>
	
</html>
